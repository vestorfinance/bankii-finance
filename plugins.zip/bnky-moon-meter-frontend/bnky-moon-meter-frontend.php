<?php
/*
Plugin Name: Moon Meter Frontend
Description: Allows users to input an investment amount and calculates potential earnings based on a multiplier.
Version: 1.0
Author: Ngonidzashe Jiji
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Function to get the BNKY token price (unique function name)
function moon_meter_get_token_price_unique() {
    return get_option('moon_meter_bnky_token_price', '0.0005'); // Fetching BNKY token price from BNKY Token Sale plugin
}

// Shortcode to display the Moon Meter with a slider and investment input (unique function name)
function moon_meter_shortcode_unique() {
    $bnky_price = moon_meter_get_token_price_unique();

    ob_start();
    ?>
    <div class="moon-meter-frontend" style="width: 100%; margin: 20px 0;">
        <label for="moon_meter_investment_amount" style="display: block; margin-bottom: 10px;">Enter the amount you want to invest ($):</label>
        <input type="number" id="moon_meter_investment_amount" class="glass-morphism" name="moon_meter_investment_amount" style="max-width: 600px; border-radius:14px;margin-bottom: 20px;background-color: rgba(255, 255, 255, 0.1);box-shadow:none;text-align:center;font-size:30px;" oninput="moonMeterUpdateBnkyAmount()">
        
        <label for="moon_meter_slider" style="display: block; margin-bottom: 10px;">Adjust the multiplier to see your potential earnings:</label>
        <input type="range" id="moon_meter_slider" name="moon_meter_slider" min="1" max="1000" value="1" style="width: 100%;" oninput="moonMeterUpdateBnkyValue(this.value)">
        
        <div id="moon_meter_multiplier" style="margin-top: 10px; font-size: 18px; font-weight: bold;">
            If $BNKY goes up by: 1x
        </div>
        
        <div id="moon_meter_bnky_amount" style="margin-top: 10px; font-size: 18px;">
            Amount of BNKY you can buy: 0
        </div>
        
        <div id="moon_meter_bnky_value" style="margin-top: 20px; font-size: 35px; font-weight: bold;">
            Potential Earnings: $0.00
        </div>
    </div>

    <script type="text/javascript">
        function moonMeterUpdateBnkyAmount() {
            var investmentAmount = document.getElementById('moon_meter_investment_amount').value;
            var bnkyPrice = <?php echo $bnky_price; ?>;
            var bnkyAmount = investmentAmount / bnkyPrice;

            document.getElementById('moon_meter_bnky_amount').innerHTML = 'Amount of BNKY you can buy: ' + bnkyAmount.toFixed(2);
            moonMeterUpdateBnkyValue(document.getElementById('moon_meter_slider').value);
        }

        function moonMeterUpdateBnkyValue(multiplier) {
            var investmentAmount = document.getElementById('moon_meter_investment_amount').value;
            var bnkyPrice = <?php echo $bnky_price; ?>;
            var bnkyAmount = investmentAmount / bnkyPrice;
            var potentialValue = bnkyAmount * bnkyPrice * multiplier;

            // Format the potential value with spaces between thousands
            var formattedValue = potentialValue.toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g, ' ');

            document.getElementById('moon_meter_multiplier').innerHTML = 'If $BNKY goes up by: ' + multiplier + 'x';
            document.getElementById('moon_meter_bnky_value').innerHTML = 'Potential Earnings: $' + formattedValue;
        }
    </script>
    <?php
    return ob_get_clean();
}
add_shortcode('moon_meter_frontend', 'moon_meter_shortcode_unique');
