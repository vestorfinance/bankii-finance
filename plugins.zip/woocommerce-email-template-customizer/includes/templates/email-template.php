<?php
do_action( 'viwec_email_template', $args );
