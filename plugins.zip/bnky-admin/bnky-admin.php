<?php
/*
Plugin Name: Bankii Token Holders
Description: Displays a list of users with a valid Bankii balance in a responsive row layout with horizontal columns and allows status updates via AJAX. Supports lazy loading with pagination. Includes shortcodes for total holders, total held tokens, and total sells.
Version: 1.9
Author: Ngonidzashe Jiji
*/

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Function to get users with a valid Bankii balance
function banki_get_token_holders($offset = 0, $limit = 100) {
    $users = get_users(array('number' => $limit, 'offset' => $offset));
    $token_holders = array();

    foreach ($users as $user) {
        $user_id = $user->ID;
        $wallet_address = get_user_meta($user_id, 'solana_wallet_address', true);
        $total_tokens = 0;

        // Calculate the total tokens for each user
        $orders = wc_get_orders(array(
            'customer_id' => $user_id,
            'status'      => 'completed',
            'limit'       => -1,
        ));

        foreach ($orders as $order) {
            foreach ($order->get_items() as $item) {
                $bnky_amount = wc_get_order_item_meta($item->get_id(), 'BNKY Amount', true);
                if ($bnky_amount) {
                    $total_tokens += floatval($bnky_amount);
                }
            }
        }

        if ($total_tokens > 0) {
            $token_holders[] = array(
                'ID' => $user_id,
                'name' => $user->display_name,
                'email' => $user->user_email,
                'country' => get_user_meta($user_id, 'billing_country', true),
                'phone' => get_user_meta($user_id, 'billing_phone', true),
                'tokens' => $total_tokens,
                'wallet_address' => $wallet_address,
                'status' => get_user_meta($user_id, 'token_status', true)
            );
        }
    }

    return $token_holders;
}

// AJAX handler to load more token holders
function banki_load_more_token_holders() {
    $offset = intval($_POST['offset']);
    $token_holders = banki_get_token_holders($offset);
    $html = '';

    foreach ($token_holders as $index => $holder) {
        $number = $offset + $index + 1;
        $html .= '<div class="token-holder-row" style="background: rgba(20, 20, 20, 1); color: white; padding: 15px; border-radius: 9px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center;">';
        $html .= '<div class="token-holder-col" style="flex: 0.5;">' . esc_html($number) . '</div>';
        $html .= '<div class="token-holder-col" style="flex: 1;">' . esc_html($holder['name']) . '</div>';
        $html .= '<div class="token-holder-col" style="flex: 1;">' . esc_html($holder['country']) . '</div>';
        $html .= '<div class="token-holder-col" style="flex: 2;">' . esc_html($holder['email']) . '</div>';
        $html .= '<div class="token-holder-col" style="flex: 1;">' . esc_html($holder['phone']) . '</div>';
        $html .= '<div class="token-holder-col" style="flex: 1;"><span class="tokens">' . number_format($holder['tokens'], 2, '.', ' ') . '</span></div>';
        $html .= '<div class="token-holder-col" style="flex: 2;">' . esc_html($holder['wallet_address']) . '</div>';
        $html .= '<div class="token-holder-col" style="flex: 1;"><select class="token-status" style="background-color: rgba(20, 20, 20, 1); color: white; border-radius: 4px;">
                <option value="Unfulfilled" ' . selected($holder['status'], 'Unfulfilled', false) . '>Unfulfilled</option>
                <option value="Phase1 Fulfilled" ' . selected($holder['status'], 'Phase1 Fulfilled', false) . '>Phase 1 Fulfilled</option>
                <option value="Phase2 Fulfilled" ' . selected($holder['status'], 'Phase2 Fulfilled', false) . '>Phase 2 Fulfilled</option>
                <option value="Phase3 Fulfilled" ' . selected($holder['status'], 'Phase3 Fulfilled', false) . '>Phase 3 Fulfilled</option>
            </select></div>';
        $html .= '</div>';
    }

    wp_send_json_success($html);
}
add_action('wp_ajax_banki_load_more_token_holders', 'banki_load_more_token_holders');
add_action('wp_ajax_nopriv_banki_load_more_token_holders', 'banki_load_more_token_holders');

// Function to export data to CSV
function banki_export_to_csv() {
    if (isset($_GET['export_csv']) && $_GET['export_csv'] == '1') {
        $token_holders = banki_get_token_holders(0, -1);

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment;filename=token_holders.csv');

        $output = fopen('php://output', 'w');
        fputcsv($output, array('Number', 'Name', 'Country', 'Email', 'Phone', 'Number of Tokens', 'Wallet Address', 'Status'));

        foreach ($token_holders as $index => $holder) {
            fputcsv($output, array(
                $index + 1,
                $holder['name'],
                $holder['country'],
                $holder['email'],
                $holder['phone'],
                number_format($holder['tokens'], 2, '.', ' '),
                $holder['wallet_address'],
                $holder['status']
            ));
        }

        fclose($output);
        exit;
    }
}
add_action('init', 'banki_export_to_csv');

// Shortcode to display the token holders with lazy loading
function banki_token_holders_shortcode() {
    $token_holders = banki_get_token_holders();

    ob_start();
    ?>
    <div style="text-align: right; margin-bottom: 10px;">
        <a href="?export_csv=1" style="background-color: rgba(0, 73, 255, 1); color: white; padding: 5px 10px; border-radius: 5px; text-decoration: none;">Export to CSV</a>
    </div>

    <div id="token-holders-container">
        <!-- Header Row -->
        <div class="token-holder-row" style="background: linear-gradient(270deg, rgba(19, 236, 171, 1) 0%, rgba(183, 13, 216, 1) 100%); font-size:14px;color: white; padding: 15px; border-radius: 9px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center; font-weight: bold;">
            <div class="token-holder-col" style="flex: 0.5;">#</div>
            <div class="token-holder-col" style="flex: 1;">Name</div>
            <div class="token-holder-col" style="flex: 1;">Country</div>
            <div class="token-holder-col" style="flex: 2;">Email</div>
            <div class="token-holder-col" style="flex: 1;">Phone</div>
            <div class="token-holder-col" style="flex: 1;">BNKY</div>
            <div class="token-holder-col" style="flex: 2;">Wallet Address</div>
            <div class="token-holder-col" style="flex: 1;">Status</div>
        </div>

        <!-- Data Rows -->
        <div id="token-holders-list">
            <?php foreach ($token_holders as $index => $holder): ?>
                <div class="token-holder-row" style="background: rgba(20, 20, 20, 1); color: white; padding: 0 15px; font-size:13px;  border-radius: 9px; margin-bottom: 10px; display: flex; justify-content: space-between; align-items: center;">
                    <div class="token-holder-col" style="flex: 0.5;"><?php echo esc_html($index + 1); ?></div>
                    <div class="token-holder-col" style="flex: 1;"><?php echo esc_html($holder['name']); ?></div>
                    <div class="token-holder-col" style="flex: 1;"><?php echo esc_html($holder['country']); ?></div>
                    <div class="token-holder-col" style="flex: 2;"><?php echo esc_html($holder['email']); ?></div>
                    <div class="token-holder-col" style="flex: 1;"><?php echo esc_html($holder['phone']); ?></div>
                    <div class="token-holder-col" style="flex: 1;"><span class="tokens"><?php echo number_format($holder['tokens'], 2, '.', ' '); ?></span></div>
                    <div class="token-holder-col" style="flex: 2;"><?php echo esc_html($holder['wallet_address']); ?></div>
                    <div class="token-holder-col" style="flex: 1;">
                        <select class="token-status" style="background-color: rgba(20, 20, 20, 1); color: white; border-radius: 4px;">
                            <option value="Unfulfilled" <?php selected($holder['status'], 'Unfulfilled'); ?>>Unfulfilled</option>
                            <option value="Phase1 Fulfilled" <?php selected($holder['status'], 'Phase1 Fulfilled'); ?>>Phase 1 Fulfilled</option>
                            <option value="Phase2 Fulfilled" <?php selected($holder['status'], 'Phase2 Fulfilled'); ?>>Phase 2 Fulfilled</option>
                            <option value="Phase3 Fulfilled" <?php selected($holder['status'], 'Phase3 Fulfilled'); ?>>Phase 3 Fulfilled</option>
                        </select>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
        <div id="load-more-message" style="text-align: center; color: white; margin-top: 20px;">Loading more...</div>
    </div>

    <script type="text/javascript">
        jQuery(document).ready(function($) {
            let offset = 100;

            function loadMoreTokenHolders() {
                $.ajax({
                    url: solanaWalletAjax.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'banki_load_more_token_holders',
                        offset: offset,
                    },
                    success: function(response) {
                        if (response.success && response.data) {
                            $('#token-holders-list').append(response.data);
                            offset += 100;
                        } else {
                            $('#load-more-message').text('No more users to load.');
                        }
                    }
                });
            }

            // Lazy load when scrolling to the bottom
            $(window).scroll(function() {
                if ($(window).scrollTop() + $(window).height() >= $(document).height() - 100) {
                    loadMoreTokenHolders();
                }
            });
        });
    </script>
    <style>
        @media (max-width: 768px) {
            .token-holder-row {
                flex-direction: column;
                align-items: flex-start;
            }
            .token-holder-col {
                margin-bottom: 10px;
            }
        }
    </style>
    <?php
    return ob_get_clean();
}
add_shortcode('banki_token_holders', 'banki_token_holders_shortcode');

// Shortcode to get the total number of token holders
function bnky_total_holders_shortcode() {
    $total_holders = count_users();
    $total_holders_with_tokens = 0;

    foreach ($total_holders['avail_roles'] as $role => $count) {
        $users = get_users(array('role' => $role));

        foreach ($users as $user) {
            $total_tokens = 0;

            $orders = wc_get_orders(array(
                'customer_id' => $user->ID,
                'status'      => 'completed',
                'limit'       => -1,
            ));

            foreach ($orders as $order) {
                foreach ($order->get_items() as $item) {
                    $bnky_amount = wc_get_order_item_meta($item->get_id(), 'BNKY Amount', true);
                    if ($bnky_amount) {
                        $total_tokens += floatval($bnky_amount);
                    }
                }
            }

            if ($total_tokens > 0) {
                $total_holders_with_tokens++;
            }
        }
    }

    return $total_holders_with_tokens;
}
add_shortcode('bnky_total_holders', 'bnky_total_holders_shortcode');

// Shortcode to get the total number of held tokens
function bnky_total_held_tokens_shortcode() {
    $total_held_tokens = 0;
    $users = get_users();

    foreach ($users as $user) {
        $total_tokens = 0;

        $orders = wc_get_orders(array(
            'customer_id' => $user->ID,
            'status'      => 'completed',
            'limit'       => -1,
        ));

        foreach ($orders as $order) {
            foreach ($order->get_items() as $item) {
                $bnky_amount = wc_get_order_item_meta($item->get_id(), 'BNKY Amount', true);
                if ($bnky_amount) {
                    $total_tokens += floatval($bnky_amount);
                }
            }
        }

        $total_held_tokens += $total_tokens;
    }

    return number_format($total_held_tokens, 2, '.', ' ');
}
add_shortcode('bnky_total_held_tokens', 'bnky_total_held_tokens_shortcode');

// Shortcode to get the total sells amount
function bnky_total_sells_shortcode() {
    $total_sells = 0;
    $orders = wc_get_orders(array('status' => 'completed'));

    foreach ($orders as $order) {
        $total_sells += floatval($order->get_total());
    }

    return '$' . number_format($total_sells, 2, '.', ' ');
}
add_shortcode('bnky_total_sells', 'bnky_total_sells_shortcode');
