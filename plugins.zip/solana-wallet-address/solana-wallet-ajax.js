jQuery(document).ready(function($) {
    $('#solana-wallet-edit').on('click', function(e) {
        e.preventDefault();
        
        var editCount = $(this).data('edit-count');
        
        if (editCount >= 3) {
            alert('You can no longer edit this address. Contact support.');
        } else {
            $('#solana-wallet-form').toggle();
        }
    });

    $('#solana-wallet-save').on('click', function() {
        var solanaWalletAddress = $('#solana-wallet-input').val();
        var nonce = solanaWalletAjax.nonce;

        $.ajax({
            url: solanaWalletAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'save_solana_wallet',
                solana_wallet_address: solanaWalletAddress,
                nonce: nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#solana-wallet-display').text(solanaWalletAddress);
                    $('#solana-wallet-form').hide();
                } else {
                    alert(response.data);
                }
            }
        });
    });
});
