<?php
/**
 * Plugin Name: Solana Wallet Checkout Field
 * Description: Adds a custom Solana wallet address field to WooCommerce checkout and provides shortcodes to display the wallet address and user information.
 * Version: 1.6
 * Author: Ngonidzashe Jiji
 */

// Add custom Solana Wallet Address field to WooCommerce checkout
function add_solana_wallet_checkout_field($fields) {
    $fields['billing']['billing_solana_wallet'] = array(
        'type'        => 'text',
        'label'       => __('Your Solana Wallet Address', 'solana-wallet-checkout'),
        'placeholder' => _x('Solana Wallet Address', 'placeholder', 'solana-wallet-checkout'),
        'required'    => true,
        'class'       => array('form-row-wide'),
        'clear'       => true,
        'description' => __('Please do not put an exchange wallet address.', 'solana-wallet-checkout'),
    );
    return $fields;
}
add_filter('woocommerce_checkout_fields', 'add_solana_wallet_checkout_field');

// Save the Solana Wallet Address to user meta
function save_solana_wallet_checkout_field($order_id) {
    if (!empty($_POST['billing_solana_wallet'])) {
        update_post_meta($order_id, '_billing_solana_wallet', sanitize_text_field($_POST['billing_solana_wallet']));
        $user_id = get_post_meta($order_id, '_customer_user', true);
        if ($user_id) {
            update_user_meta($user_id, 'solana_wallet_address', sanitize_text_field($_POST['billing_solana_wallet']));
        }
    }
}
add_action('woocommerce_checkout_update_order_meta', 'save_solana_wallet_checkout_field');

// Enqueue JavaScript for AJAX handling
function solana_wallet_enqueue_scripts() {
    wp_enqueue_script('solana-wallet-ajax', plugin_dir_url(__FILE__) . 'solana-wallet-ajax.js', array('jquery'), null, true);
    wp_localize_script('solana-wallet-ajax', 'solanaWalletAjax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('solana_wallet_nonce')
    ));
}
add_action('wp_enqueue_scripts', 'solana_wallet_enqueue_scripts');

// Handle the AJAX request to save the Solana wallet address
function solana_wallet_save_address() {
    check_ajax_referer('solana_wallet_nonce', 'nonce');

    $user_id = get_current_user_id();
    if (!$user_id) {
        wp_send_json_error('User not logged in');
    }

    $edit_count = get_user_meta($user_id, 'solana_wallet_edit_count', true);
    $edit_count = $edit_count ? intval($edit_count) : 0;

    if ($edit_count >= 3) {
        wp_send_json_error('You can no longer edit this address. Contact support.');
    }

    if (isset($_POST['solana_wallet_address'])) {
        $new_address = sanitize_text_field($_POST['solana_wallet_address']);
        update_user_meta($user_id, 'solana_wallet_address', $new_address);
        $edit_count++;
        update_user_meta($user_id, 'solana_wallet_edit_count', $edit_count);
        wp_send_json_success('Address saved successfully');
    } else {
        wp_send_json_error('No address provided');
    }
}
add_action('wp_ajax_save_solana_wallet', 'solana_wallet_save_address');

// Display Solana Wallet Address with Edit/Add functionality
function user_solana_wallet_shortcode() {
    $user_id = get_current_user_id();
    $solana_wallet = get_user_meta($user_id, 'solana_wallet_address', true);
    $edit_count = get_user_meta($user_id, 'solana_wallet_edit_count', true);
    $edit_count = $edit_count ? intval($edit_count) : 0;

    ob_start();
    ?>
    <div id="solana-wallet-container">
        <span id="solana-wallet-display"><?php echo $solana_wallet ? esc_html($solana_wallet) : __('No Solana wallet address found.', 'solana-wallet-checkout'); ?></span>
        <a href="#" id="solana-wallet-edit" style="color: rgba(0,73,255,1);" data-edit-count="<?php echo $edit_count; ?>">
            <?php echo $solana_wallet ? __('Edit', 'solana-wallet-checkout') : __('Add', 'solana-wallet-checkout'); ?>
        </a>
        <div id="solana-wallet-form" style="display:none;">
            <input type="text" style="border: 1px solid #fff;margin-top:10px;border-radius:9px;" id="solana-wallet-input" value="<?php echo esc_attr($solana_wallet); ?>">
            <button id="solana-wallet-save" class="tbutton .tatsu-Hyl6Cn8fR mediumbtn tatsu-button" style="width: 100%; border-radius: 9px;background:#1d1d1d;margin-top:15px;"><?php _e('Save', 'solana-wallet-checkout'); ?></button>
        </div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('user_solana_wallet', 'user_solana_wallet_shortcode');

// Display Username or First Name shortcode
function username_shortcode() {
    $user_id = get_current_user_id();
    if ($user_id) {
        $first_name = get_user_meta($user_id, 'first_name', true);
        if ($first_name) {
            return esc_html($first_name);
        } else {
            $user_info = get_userdata($user_id);
            return esc_html($user_info->user_login);
        }
    }
    return __('Guest', 'solana-wallet-checkout');
}
add_shortcode('username', 'username_shortcode');

// Set the Edit Page ID on plugin activation
register_activation_hook(__FILE__, 'set_solana_edit_page_id');

function set_solana_edit_page_id() {
    $edit_page = get_page_by_path('edit-solana-wallet');
    if ($edit_page) {
        update_option('solana_edit_page_id', $edit_page->ID);
    }
}
